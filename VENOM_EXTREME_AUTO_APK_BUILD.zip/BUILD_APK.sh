#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/android"
gradle :app:assembleRelease --no-daemon
echo "APK: app/build/outputs/apk/release/app-release.apk"
