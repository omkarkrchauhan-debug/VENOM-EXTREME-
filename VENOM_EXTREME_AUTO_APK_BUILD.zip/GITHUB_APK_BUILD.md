# VENOM EXTREME — Automatic APK Build

This package is prepared so GitHub Actions can build the Android release APK after the repository is uploaded.

## What the workflow does
1. Checks out the repository.
2. Installs Java 17.
3. Installs Android SDK platform 35 and build tools.
4. Installs Gradle 8.10.2.
5. Runs `:app:assembleRelease`.
6. Uploads `app-release.apk` as a GitHub Actions artifact.

## Phone-only use
After uploading the project to a GitHub repository:
- Open **Actions**.
- Select **Build VENOM APK**.
- Tap **Run workflow** (if it has not already run from the upload).
- Open the successful run.
- Under **Artifacts**, download `VENOM-release-apk`.
- Extract the artifact ZIP and install `app-release.apk`.

The workflow is public build automation; no API keys are included in the APK.
