# VENOM EXTREME — APK-ready source

I fixed the Android module's Compose dependency setup, release configuration, manifest speech-recognition query, and added a GitHub Actions workflow that builds the APK automatically.

## Phone-only build route
1. Upload this project to a GitHub repository from your Android browser/app.
2. Open the repository's **Actions** tab.
3. Run **Build VENOM APK** (or push to `main`).
4. When the workflow finishes, open its run and download the **VENOM-release-apk** artifact.
5. Extract the artifact and install `app-release.apk`.

The build still needs the VENOM backend/AI provider to be deployed separately for full AI functionality. Never put a private API key in the Android source or APK.
