# VENOM EXTREME — Complete Full-Stack Starter

This package combines the planned VENOM architecture into one project:
Android client + FastAPI backend contract + local persistence foundations + AI/agent modules + study/memory/security concepts.

## What is included
Android:
- VENOM dark UI
- Chat
- local chat history
- chat search/delete foundation
- voice input (Android SpeechRecognizer)
- text-to-speech
- selectable voice profiles
- Hindi/English/Hinglish preference
- personality modes
- NEET dashboard
- memory center
- routines
- security/permission center
- device/session foundation
- action confirmation concept
- backend URL setting

Backend:
- FastAPI skeleton
- auth models/contracts
- conversations
- memory
- study progress
- device pairing/session concepts
- activity/audit log
- agent planner interface
- tool allowlist/confirmation interface
- AI provider interface
- search/vision interface contracts

## Reality check
A production-grade assistant cannot be made into a universally unrestricted phone controller. Android controls what a third-party app may do, and sensitive actions require OS permissions and/or explicit user confirmation.

An AI provider API key must NOT be placed in the APK. Put it on the backend.

This package is designed so the remaining deployment-specific values (backend hosting, database credentials, AI provider credentials, OAuth configuration) are centralized rather than requiring repeated code changes.


## APK build
See `GITHUB_APK_BUILD.md`. GitHub Actions builds the release APK automatically.
