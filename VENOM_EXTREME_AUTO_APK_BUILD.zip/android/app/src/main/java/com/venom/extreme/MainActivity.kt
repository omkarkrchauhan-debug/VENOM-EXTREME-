package com.venom.extreme

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.util.Locale

data class Msg(val text:String, val user:Boolean)
enum class Mode(val title:String){ FRIEND("Friend"), TEACHER("Teacher"), CODER("Coder"), RESEARCH("Research"), NEET("NEET"), ASSISTANT("Assistant") }
enum class Voice(val title:String){ VENOM("VENOM"), CORE("AI Core"), CINEMATIC("Cinematic"), NATURAL("Natural"), TEACHER("Teacher"), CALM("Calm"), ENERGETIC("Energetic") }

class MainActivity: ComponentActivity() {
    private var tts: TextToSpeech? = null
    private val mic = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this){ if(it==TextToSpeech.SUCCESS) tts?.language=Locale.US }
        setContent { VenomExtreme({ if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) mic.launch(Manifest.permission.RECORD_AUDIO) },
            { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "venom") }) }
    }
    override fun onDestroy(){ tts?.shutdown(); super.onDestroy() }
}

@Composable
fun VenomExtreme(requestMic:()->Unit, speak:(String)->Unit){
    var tab by remember{mutableStateOf("Chat")}
    var mode by remember{mutableStateOf(Mode.ASSISTANT)}
    var voice by remember{mutableStateOf(Voice.VENOM)}
    var input by remember{mutableStateOf("")}
    var backend by remember{mutableStateOf("http://10.0.2.2:8000")}
    var msgs by remember{mutableStateOf(listOf(Msg("VENOM EXTREME online. Full-stack architecture loaded.",false)))}
    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF7CFF00),background=Color(0xFF060606),surface=Color(0xFF111111))){
        Scaffold(bottomBar={
            NavigationBar(containerColor=Color(0xFF0C0C0C)){
                listOf("Chat","Study","Memory","Security","Settings").forEach{ t->
                    NavigationBarItem(tab==t,{tab=t},icon={Icon(when(t){
                        "Study"->Icons.Default.School
                        "Memory"->Icons.Default.Psychology
                        "Security"->Icons.Default.Shield
                        "Settings"->Icons.Default.Settings
                        else->Icons.Default.Chat
                    },t)},label={Text(t)})
                }
            }
        }){p->
            when(tab){
                "Chat"->Chat(p,msgs,input,{input=it},mode,{mode=it},voice,{voice=it},{
                    if(input.isNotBlank()){
                        val u=input.trim()
                        val a=demo(u,mode)
                        msgs=msgs+Msg(u,true)+Msg(a,false); input=""; speak(a)
                    }
                },requestMic)
                "Study"->Study(p)
                "Memory"->Memory(p)
                "Security"->Security(p)
                else->Settings(p,voice,{voice=it},backend,{backend=it})
            }
        }
    }
}
@Composable fun Chat(p:PaddingValues,m:List<Msg>,input:String,onInput:(String)->Unit,mode:Mode,onMode:(Mode)->Unit,voice:Voice,onVoice:(Voice)->Unit,send:()->Unit,mic:()->Unit){
    Column(Modifier.padding(p).fillMaxSize()){
        Column(Modifier.padding(16.dp)){
            Text("VENOM",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold)
            Text("EXTREME • ${voice.title} • ${mode.title}",color=MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Row{ Mode.entries.take(4).forEach{FilterChip(mode==it,{onMode(it)},label={Text(it.title)},modifier=Modifier.padding(end=4.dp))}}
        }
        LazyColumn(Modifier.weight(1f).padding(10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(m){x->Surface(Modifier.fillMaxWidth(),color=if(x.user)Color(0xFF202020) else Color(0xFF111A0A),shape=MaterialTheme.shapes.large){Text(x.text,Modifier.padding(14.dp))}}
        }
        Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){
            OutlinedTextField(input,onInput,Modifier.weight(1f),placeholder={Text("Talk to VENOM…")},singleLine=true)
            IconButton(mic){Icon(Icons.Default.Mic,"Voice")}
            IconButton(send){Icon(Icons.Default.Send,"Send")}
        }
    }
}
@Composable fun Study(p:PaddingValues){
    Column(Modifier.padding(p).fillMaxSize().padding(16.dp)){
        Text("NEET SUPER MODE",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        listOf("Today's target" to "3h 30m","Physics" to "54%","Chemistry" to "61%","Biology" to "72%","Weak topics" to "6","Mistakes" to "23","Next revision" to "Tomorrow").forEach{
            ElevatedCard(Modifier.fillMaxWidth().padding(vertical=4.dp)){Row(Modifier.padding(15.dp)){Text(it.first);Spacer(Modifier.weight(1f));Text(it.second,color=MaterialTheme.colorScheme.primary)}}
        }
    }
}
@Composable fun Memory(p:PaddingValues){
    Column(Modifier.padding(p).fillMaxSize().padding(16.dp)){
        Text("MEMORY CENTER",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("User-controlled long-term memory")
        Spacer(Modifier.height(12.dp))
        Button({}){Text("Add memory")}
        OutlinedButton({}){Text("Review / delete memory")}
        OutlinedButton({}){Text("Clear local chat cache")}
    }
}
@Composable fun Security(p:PaddingValues){
    Column(Modifier.padding(p).fillMaxSize().padding(16.dp)){
        Text("SECURITY CENTER",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        listOf("Microphone" to "Permission-controlled","Camera" to "Permission-controlled","Notifications" to "Permission-controlled","PC Agent" to "Not connected","Active sessions" to "1","Activity log" to "Enabled").forEach{
            ListItem(headlineContent={Text(it.first)},supportingContent={Text(it.second)})
        }
        Text("Sensitive actions require confirmation.",color=MaterialTheme.colorScheme.primary)
    }
}
@Composable fun Settings(p:PaddingValues,v:Voice,setV:(Voice)->Unit,b:String,setB:(String)->Unit){
    Column(Modifier.padding(p).fillMaxSize().padding(16.dp)){
        Text("SETTINGS",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Voice",style=MaterialTheme.typography.titleLarge)
        Voice.entries.forEach{x->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(v==x,{setV(x)});Text(x.title)}}
        Text("Backend endpoint",style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(b,setB,Modifier.fillMaxWidth(),singleLine=true)
        Text("API keys belong on the backend, never inside the APK.",color=MaterialTheme.colorScheme.primary)
    }
}
fun demo(s:String,m:Mode)=when{
    s.lowercase().contains("hello")->"VENOM online. What are we doing?"
    m==Mode.NEET->"NEET mode active. Connect the backend to enable AI planning, NCERT reasoning, MCQs, tests and analytics."
    else->"I received: \"$s\". Connect the VENOM backend for the full AI brain and agent tools."
}
