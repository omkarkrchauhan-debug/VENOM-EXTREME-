from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from uuid import uuid4
from datetime import datetime

app = FastAPI(title="VENOM EXTREME API", version="1.0.0")

users = {}
chats = {}
memories = {}
activity = []

class Signup(BaseModel):
    email: str
    password: str

class Login(Signup): pass

class ChatIn(BaseModel):
    conversation_id: Optional[str] = None
    message: str
    mode: str = "assistant"
    device_id: Optional[str] = None

@app.get("/health")
def health(): return {"status":"online","service":"VENOM EXTREME"}

@app.post("/v1/auth/signup")
def signup(x: Signup):
    if x.email in users: raise HTTPException(409,"Account exists")
    users[x.email]={"password":x.password,"id":str(uuid4())}
    return {"user_id":users[x.email]["id"]}

@app.post("/v1/auth/login")
def login(x: Login):
    u=users.get(x.email)
    if not u or u["password"]!=x.password: raise HTTPException(401,"Invalid credentials")
    return {"user_id":u["id"],"session_id":str(uuid4())}

@app.post("/v1/chat")
def chat(x: ChatIn):
    cid=x.conversation_id or str(uuid4())
    chats.setdefault(cid,[]).append({"role":"user","text":x.message,"time":datetime.utcnow().isoformat()})
    # Provider-neutral placeholder. Put the real AI provider call here on the server.
    reply=f'VENOM received: "{x.message}". Mode={x.mode}. The provider adapter is ready to be connected.'
    chats[cid].append({"role":"assistant","text":reply,"time":datetime.utcnow().isoformat()})
    activity.append({"event":"chat","conversation_id":cid,"device_id":x.device_id,"time":datetime.utcnow().isoformat()})
    return {"conversation_id":cid,"reply":reply,"actions":[],"memory_updates":[]}

@app.get("/v1/chats")
def list_chats(): return chats

@app.delete("/v1/chats/{cid}")
def delete_chat(cid:str):
    chats.pop(cid,None)
    return {"deleted":cid}

@app.get("/v1/memory")
def get_memory(): return memories

@app.post("/v1/memory")
def add_memory(item:dict):
    mid=str(uuid4()); memories[mid]=item
    return {"id":mid,**item}

@app.delete("/v1/memory/{mid}")
def delete_memory(mid:str):
    memories.pop(mid,None); return {"deleted":mid}

@app.get("/v1/activity")
def get_activity(): return activity[-200:]

@app.get("/v1/devices")
def devices(): return {"devices":[]}

@app.get("/v1/study")
def study(): return {"physics":54,"chemistry":61,"biology":72,"weak_topics":[],"mistakes":[]}

@app.post("/v1/agent/plan")
def plan(goal:dict):
    return {"plan":["understand goal","select tools","request confirmation when required","execute","verify","report"],"goal":goal}
