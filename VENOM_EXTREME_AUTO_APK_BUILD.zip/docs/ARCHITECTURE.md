# VENOM EXTREME Architecture

Android Client
    |
    v
Authenticated API
    |
    +-- AI Provider Adapter
    +-- Planner / Agent Orchestrator
    +-- Memory
    +-- Conversation Store
    +-- Study Engine
    +-- Research/Search Adapter
    +-- Vision Adapter
    +-- Device/PC Gateway
    +-- Security / Confirmation
    +-- Activity Audit

The planner should never execute arbitrary instructions. Each tool must have:
1. an allowlist,
2. declared permissions,
3. risk level,
4. confirmation policy,
5. audit event,
6. timeout/error handling.

Phone control uses Android-supported APIs and Intents. Background microphone/wake-word behavior must follow Android foreground-service and permission rules.
