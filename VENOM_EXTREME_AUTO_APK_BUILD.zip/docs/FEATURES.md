# VENOM EXTREME Feature Matrix

## Core
- conversation engine
- planner/executor/verifier architecture
- configurable personality
- memory retrieval
- multilingual chat

## Voice
- SpeechRecognizer input
- Android TextToSpeech output
- voice profile selector
- voice speed/pitch settings foundation
- wake-word architecture placeholder
- interruption/stop architecture

## Phone
- supported Intent/deep-link actions
- reminders/calendar architecture
- notification assistant architecture
- camera/vision entry point
- clipboard assistant
- confirmation gate for sensitive actions

## Study
- NEET subjects
- chapter progress
- tests/MCQs
- scores
- weak-topic analytics
- mistake notebook
- revision scheduler

## Cloud
- accounts
- conversations
- memories
- devices
- sessions
- activity logs

## Agents
- research
- coding
- vision
- study
- phone
- PC
- planner
- memory
- security

## Customization
- voice
- language
- personality
- response length
- theme
- wake-word setting
- backend/model configuration
